package com.example.untarest_app_moobprog

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
